"use client";

import React, { useState } from "react";
import Image from "next/image";
import styles from "./events.module.css";

import image1 from "./_Components/deval_pan_digi.jpeg"

export default function Page() {
  const [isExpanded, setIsExpanded] = useState(false);

  const handleExpand = () => setIsExpanded(true);
  const handleReset = () => setIsExpanded(false);

  return (
    <main>
      <div className={styles.mainPage}>
        <div className={`${styles.left} ${isExpanded ? styles.visible : ""}`}>
          <h1 className={styles.heading}>PRONITES</h1>
          <p>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maiores
            expedita esse autem in consequuntur? Repudiandae earum dignissimos voluptate tempora! Similique tenetur
            non laborum mollitia quos voluptatem nostrum eligendi fuga inventore.
          </p>
          <button className={styles.enter}>enter</button>
        </div>
        <div className={styles.center}>
          <div
            className={`${styles.mainImage} ${
              isExpanded ? styles.mainImageExpanded : ""
            }`}
          >
            {/* <Image
              src={frame}
              className={styles.frame}
              alt="Frame"
              quality={100}
              width={500}
              height={500}
            /> */}
            <Image
              src={image1}
              className={styles.image1}
              alt="show's image"
              quality={100}
              width={500}
              height={500}
            />
          </div>
          <button className={styles.check} onClick={handleExpand}>
            Click Me
          </button>
          <button className={styles.check2} onClick={handleReset}>
            Refresh
          </button>
        </div>
        <div className={styles.right}></div>
      </div>
    </main>
  );
}
